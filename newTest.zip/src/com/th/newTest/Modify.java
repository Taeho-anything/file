package com.th.newTest;

import com.th.newTest.Data.Data;
import com.th.newTest.Data.Post;
import com.th.newTest.Utill.Ci;
import com.th.newTest.Utill.Cw;

public class Modify {

	static void run() {
		Cw.wn();
		Cw.line();
		Cw.wn("글수정");
		
		String cmd = Ci.r("수정할 글번호 ");
		for (Post p:Data.posts) {
			String content = Ci.rl("수정할 내용 ");
			
			
			p.content = content;
			
			Cw.wn("수정완료");
			
			
			
		}
		
		
		
		
	}
	
	
}
