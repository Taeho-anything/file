package com.th.newTest;

import com.th.newTest.Data.Data;
import com.th.newTest.Utill.Ci;
import com.th.newTest.Utill.Cw;

public class Delete {
	
	static void run() {
		Cw.wn();
		Cw.line();
		Cw.wn("글삭제");
		
		int index = 0;
		String cmd = Ci.r("삭제할 번호 입력 ");
		for(int i=0; i<Data.posts.size(); i++) {
			if(cmd.equals(Data.posts.get(i).insNo+"")){
				index=i;
			}
		}
		
		
		Data.posts.remove(index);
		Cw.wn("삭제가 완료됐습니다.");
		
		
		
		
	}

}
