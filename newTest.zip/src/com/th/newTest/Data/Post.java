package com.th.newTest.Data;

import java.time.LocalDate;

import com.th.newTest.Utill.Cw;

public class Post {

	public static int no = 0;

	public int insNo;
	public String title;
	public String writer;
	public String content;
	public String date;
	public int hit;

	public Post(String title, String content, String writer, int hit) {

		no = no + 1;
		insNo = no;

		this.title = title;
		this.writer = writer;
		this.content = content;
		this.hit = hit;
		LocalDate now = LocalDate.now();
		date = now.toString();

	}

	
	public void infoList() {
		Cw.wn("글번호: "+insNo);
		Cw.wn("제목: "+title);
		Cw.wn("작성자: "+writer);
		Cw.wn("작성일: "+date);
		Cw.wn("조회수: "+hit);
		
	}
	public void infoRead() {
		Cw.wn("글번호: "+insNo);
		Cw.wn("제목: "+title);
		Cw.wn("내용: "+content);
		Cw.wn("작성자: "+writer);
		Cw.wn("작성일: "+date);
		Cw.wn("조회수: "+hit);
		
	}
	
	
	
	
}
