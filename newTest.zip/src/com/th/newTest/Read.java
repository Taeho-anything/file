package com.th.newTest;

import com.th.newTest.Data.Data;
import com.th.newTest.Data.Post;
import com.th.newTest.Utill.Cw;

public class Read {
	
	static void run() {
		Cw.wn();
		Cw.line();
		Cw.wn("글 읽기");
		Cw.wn();
		
		for(Post p:Data.posts) {
			p.infoRead();
			Cw.wn();
		}
		
		
		
		
	}

}
