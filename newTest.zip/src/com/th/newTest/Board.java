package com.th.newTest;

import com.th.newTest.Data.Data;
import com.th.newTest.Display.Disp;
import com.th.newTest.Utill.Ci;
import com.th.newTest.Utill.Cw;

public class Board {
	static void run() {

		Data.loadData();
		Disp.title();

		loop: while (true) {
			Cw.wn();
			Disp.mainMenu();
			String cmd = Ci.r("명력어 입력 ");
			Cw.wn();
			switch (cmd) {
			case "1":
				List.run();
				break;
			case "2":
				Read.run();
				break;
			case "3":
				Write.run();
				break;
			case "4":
				Delete.run();
				break;
			case "5":
				Modify.run();
				break;
			case "e":
				Cw.wn("게시판을 닫습니다.");
				break loop;
			default:
				Cw.wn("잘못 입력했습니다. 다시 입력해주세요!");

			}

		}

	}

}
