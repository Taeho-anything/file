package com.th.newTest.Display;

import com.th.newTest.Utill.Cw;

public class Disp {

	public static void title() {
		Cw.line();
		Cw.dot(14);
		Cw.w("게시판");
		Cw.dot(14);
		Cw.wn();
		Cw.line();
		Cw.wn();
	}

	
	public static void mainMenu() {
		
		Cw.wn("[1.리스트 / 2.읽기 / 3.쓰기 / 4.삭제 / 5.수정 / e.종료]");
		
		
		
		
	}
	
}
