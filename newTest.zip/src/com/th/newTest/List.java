package com.th.newTest;

import com.th.newTest.Data.Data;
import com.th.newTest.Data.Post;
import com.th.newTest.Utill.Cw;

public class List {
	
	static void run() {
		Cw.wn();
		Cw.line();
		Cw.wn("글 리스트 확인");
		Cw.wn();
		
		for(Post p:Data.posts) {
			p.infoList();
			Cw.wn();
		}
		
		
		
		
		
	}
	
	

}
