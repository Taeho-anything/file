package com.th.newTest;

import com.th.newTest.Data.Data;
import com.th.newTest.Data.Post;
import com.th.newTest.Utill.Ci;
import com.th.newTest.Utill.Cw;

public class Write {

	static void run() {
		Cw.wn();
		Cw.line();
		Cw.wn("글쓰기");

		String title;
		while (true) {
			title = Ci.rl("글제목 입력 ");
			if (title.length() > 0) {
				break;
			} else {
				Cw.wn("다시 입력해주세요");
			}
		}
		
		String content;
		while (true) {
			content = Ci.rl("글내용 입력 ");
			if (content.length() > 0) {
				break;
			} else {
				Cw.wn("다시 입력해주세요");
			}
		}
		
		String writer;
		while (true) {
			writer = Ci.rl("글쓴이 입력 ");
			if (writer.length() > 0) {
				break;
			} else {
				Cw.wn("다시 입력해주세요");
			}
		}
		
		Post p = new Post(title, content, writer, 0);
		
		Data.posts.add(p);
		
		Cw.wn("글작성 종료");
		
		
		
		
		
		
		
		
		
		
		

	}

}
