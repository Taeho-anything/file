package com.th.Board;

public class Disp {
	
	public static void title() {
		System.out.println("========================================");
		System.out.println("================= 게시판 =================");
		System.out.println("========================================");
		
	}

	public static void title_m() {
		System.out.println("[1.글리스트 2.글읽기 3.글쓰기 4.글삭제 5.글수정 e.종료]");
		
	}
	
}
