package com.th.cat.utill;

public class Disp {

	String x = "x";

	final static String DOT = "○";

	public static void line() {
		Cw.wn("○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○");

	}

	
	public static void title() {
		Cw.wn("○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○");
		Cw.wn("○○○○○○○○○○○○○○○○ My Store ○○○○○○○○○○○○○○○○○○○");
		Cw.wn("○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○");
		Cw.wn("");
	}
	
	
	
}
