package com.th.cat.cafe;

import com.th.cat.utill.Cw;
import com.th.cat.utill.Disp;

public class Kiosk {

//===============================================================
//===============================================================
	void run() {
		KioskObj.productLoad_m();
		KioskObj.productLoad_c();
		KioskObj.productLoad_t();
		loop_a: while (true) {
			Disp.title();
			Cw.wn("[1.식사 / 2.카페 / 3.배달 / 4.숙박 / 5.로또 / 6.미니게임]");

			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {

//===============================================================
			case "1":
				Meal.meal_run();
				break;
//===============================================================
			case "2":
				Cafe.cafe_run();
				break;
//===============================================================
			case "3":
				Delivery.del_run();
				break;
//===============================================================
			case "4":
				Cw.wn("");
				Cw.wn("[선택] 4.숙박");
				Cw.wn("[1.대실 / 2.숙박]");

				loop_e: while (true) {
					KioskObj.cmd = KioskObj.sc.next();
					switch (KioskObj.cmd) {
					case "1":
						Cw.wn("[선택] 1.대실");
						break;
					case "2":
						Cw.wn("[선택] 1.대실");
						break;
					case "x":
						Cw.wn("[이전메뉴]");
						break loop_e;
					}
				}
				break;
//===============================================================
			case "5":
				Cw.wn("");
				Cw.wn("[선택] 5.로또");
				Cw.wn("아직 개발되지 않았습니다.");
				Cw.wn("");
				break;
//===============================================================
			case "6":
				Cw.wn("");
				Cw.wn("[선택] 6.미니게임");
				Cw.wn("아직 개발되지 않았습니다.");
				Cw.wn("");
				break;
//===============================================================
			case "x":
				Cw.wn("프로그램 종료");
				break loop_a;
			}
//===============================================================
		}
	}
}
