package com.th.cat.cafe;

import com.th.cat.utill.Cw;

public class Cafe {

	public static void cafe_run() {

		Cw.wn("[선택] 2.카페");
		Cw.wn("[1.커피 / 2.티 / x.이전메뉴]");

		loop_c: while (true) {

			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				System.out.println("[선택] 1.커피");

				loop_c1: while (true) {

					for (Product p : KioskObj.products_c) {
						Cw.wn("["+p.name + " " + p.price + "원]");
					}
					Cw.wn("[이전메뉴 x]");
					
					KioskObj.cmd = KioskObj.sc.next();
					switch (KioskObj.cmd) {
					case "1":
						Cw.wn("[선택] 1." + KioskObj.products_c.get(0).name);
						Cw.wn("");
						break;
					case "2":
						Cw.wn("[선택] 2." + KioskObj.products_c.get(1).name);
						Cw.wn("[1.HOT / 2.ICE / x.이전메뉴]");
						loop_cc1: while (true) {
							KioskObj.cmd = KioskObj.sc.next();
							switch (KioskObj.cmd) {
							case "1":
								Cw.wn("[선택] 1." + KioskObj.products_c.get(1).name + " HOT");
								Cw.wn("");
								break loop_cc1;
							case "2":
								Cw.wn("[선택] 2." + KioskObj.products_c.get(1).name + " ICE");
								Cw.wn("");
								break loop_cc1;
							case "x":
								Cw.wn("[이전메뉴]");
								Cw.wn("");
								break loop_cc1;
							}
						}
						break;
					case "3":
						Cw.wn("[선택] 3." + KioskObj.products_c.get(2).name);
						Cw.wn("[1.HOT / 2.ICE / x.이전메뉴]");
						loop_cc2: while (true) {
							KioskObj.cmd = KioskObj.sc.next();
							switch (KioskObj.cmd) {
							case "1":
								Cw.wn("[선택] 1." + KioskObj.products_c.get(2).name + " HOT");
								Cw.wn("");
								break loop_cc2;
							case "2":
								Cw.wn("[선택] 1." + KioskObj.products_c.get(2).name + " ICE");
								Cw.wn("");
								break loop_cc2;
							case "x":
								Cw.wn("[이전메뉴]");
								Cw.wn("");
								break loop_cc2;

							}
						}
						break;
					case "4":
						Cw.wn("[선택] 4." + KioskObj.products_c.get(3).name);
						Cw.wn("[1.HOT / 2.ICE / x.이전메뉴]");
						loop_cc3: while (true) {
							KioskObj.cmd = KioskObj.sc.next();
							switch (KioskObj.cmd) {
							case "1":
								Cw.wn(KioskObj.products_c.get(3).name + " HOT");
								Cw.wn("");
								break loop_cc3;
							case "2":
								Cw.wn(KioskObj.products_c.get(3).name + " ICE");
								Cw.wn("");
								break loop_cc3;
							case "x":
								Cw.wn("[이전메뉴]");
								Cw.wn("");
								break loop_cc3;

							}
						}
						break;
					case "x":
						Cw.wn("[이전메뉴]");
						Cw.wn("");
						break loop_c1;
					}
				}
				break;

			case "2":

				loop_c2: while (true) {
					Cw.wn("[" + KioskObj.products_t.get(0).name+"]");
					Cw.wn("[" + KioskObj.products_t.get(4).name+"]");
					Cw.wn("[" + KioskObj.products_t.get(5).name+"]");
					Cw.wn("[" + KioskObj.products_t.get(6).name+"]");
					Cw.wn("[이전메뉴 x]");
					KioskObj.cmd = KioskObj.sc.next();
					switch (KioskObj.cmd) {
					case "1":
						Cw.wn("[선택] 1." + KioskObj.products_t.get(0).name);
						Cw.wn("");
						Cw.wn("1)" + KioskObj.products_t.get(1).name);
						Cw.wn("2)" + KioskObj.products_t.get(2).name);
						Cw.wn("3)" + KioskObj.products_t.get(3).name);
						Cw.wn("x)[이전메뉴]");
						loop_c2c: while (true) {
							KioskObj.cmd = KioskObj.sc.next();
							switch (KioskObj.cmd) {
							case "1":
								Cw.wn(KioskObj.products_t.get(1).name);
								Cw.wn("");
								break loop_c2c;
							case "2":
								Cw.wn(KioskObj.products_t.get(2).name);
								Cw.wn("");
								break loop_c2c;
							case "3":
								Cw.wn(KioskObj.products_t.get(3).name);
								Cw.wn("");
								break loop_c2c;
							case "x":
								Cw.wn("[이전메뉴]");
								break loop_c2c;
							}
						}

						break;
					case "2":
						Cw.wn("[선택] 2." + KioskObj.products_t.get(4).name);
						Cw.wn("");
						break;
					case "3":
						Cw.wn("[선택] 3." + KioskObj.products_t.get(5).name);
						Cw.wn("");
						break;
					case "4":
						Cw.wn("[선택] 4." + KioskObj.products_t.get(6).name);
						Cw.wn("");
						break;
					case "x":
						Cw.wn("[이전메뉴]");
						Cw.wn("");
						break loop_c2;
					}
				}
			case "x":
				Cw.wn("[이전메뉴]");
				break loop_c;
			}
			break;

		}
	}
}
