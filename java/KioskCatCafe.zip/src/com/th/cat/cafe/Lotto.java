package com.th.cat.cafe;

import java.util.Arrays;
import java.util.Scanner;

public class Lotto {
	
	Lotto(){};
	
	void Start() {
//===================================================================
		System.out.println("번호 7개를 입력하시오 (1~45)");
		int user[] = new int[7];
		Scanner sc = new Scanner(System.in);

		for (int i = 0; i <= 6; i++) {
			user[i] = sc.nextInt();

		}

		System.out.println(Arrays.toString(user));

//===================================================================
		int lotto[] = new int[6];

		int random;
		for (int i = 0; i <= 5; i++) {
			random = (int) (Math.floor(Math.random() * 45) + 1);

			lotto[i] = random;

			for (int j = 0; j < i; j++) {
				if (lotto[i] == lotto[j]) {
					i--;
					break;
				}
			}
		}
		System.out.println(Arrays.toString(lotto));
//=====================================================================
		int c = 0;

		for (int i = 0; i <= 6; i++) {
			for (int j = 0; j <= 5; j++) {
				if (user[i] == lotto[j]) {
					c = c + 1;
				}
			}
		}
		System.out.println(c);

//=====================================================================

		switch (c) {
		case 0:
		case 1:
		case 2:
			System.out.println("꽝 다음기회에 ㅋㅋㅋㅋ");
			break;
		case 3:
			System.out.println("5등입니다~");
			break;
		case 4:
			System.out.println("4등이에요 이돈으로 다시사자");
			break;
		case 5:
			System.out.println("3등입니다 여기까진 달달하다");
			break;
		case 6:
			System.out.println("1등입니다 ㅊㅋㅊㅋ");
			break;
		}

	}
}
