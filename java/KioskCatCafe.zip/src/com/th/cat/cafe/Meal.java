package com.th.cat.cafe;

import com.th.cat.utill.Cw;

public class Meal {

	public static void meal_run() {



		loop_b: while (true) {
			Cw.wn("[선택] 1.식사");
			for(Product p:KioskObj.products_m) {
				Cw.wn("["+p.name+" "+p.price+"원]");
			}
			Cw.wn("[이전메뉴 x]");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				Cw.wn("[선택] 1."+KioskObj.products_m.get(0).name);
				Cw.wn("");
				break;
			case "2":
				Cw.wn("[선택] 2."+KioskObj.products_m.get(1).name);
				Cw.wn("");
				break;
			case "3":
				Cw.wn("[선택] 3."+KioskObj.products_m.get(2).name);
				Cw.wn("");
				break;
			case "4":
				Cw.wn("[선택] 4."+KioskObj.products_m.get(3).name);
				Cw.wn("");
				break;
			case "5":
				Cw.wn("[선택] 5."+KioskObj.products_m.get(4).name);
				Cw.wn("");
				break;
			case "x":
				Cw.wn("[이전메뉴]");
				Cw.wn("");
				break loop_b;
			}
		}
	}
}
