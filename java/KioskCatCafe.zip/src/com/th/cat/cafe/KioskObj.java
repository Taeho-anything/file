package com.th.cat.cafe;

import java.util.ArrayList;
import java.util.Scanner;

public class KioskObj {

	public static ArrayList<Product> products_m = new ArrayList<Product>();
	public static ArrayList<Product> products_c = new ArrayList<Product>();
	public static ArrayList<Product> products_t = new ArrayList<Product>();
//	ArrayList<Order> basket = new ArrayList<Order>();
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;

	// ===============================================================
	public static void productLoad_m() {
		products_m.add(new Product("제육볶음", 8000));
		products_m.add(new Product("치즈돈까스", 9000));
		products_m.add(new Product("새싹비빔밥", 6500));
		products_m.add(new Product("샐러드", 8000));
	}

	// ===============================================================
	public static void productLoad_c() {
		products_c.add(new Product("에스프레소", 2000));
		products_c.add(new Product("아메리카노", 2500));
		products_c.add(new Product("카페라떼", 3000));
		products_c.add(new Product("바닐라라떼", 3500));
	}

	// ===============================================================
	public static void productLoad_t() {
		products_t.add(new Product("허브티", 4000));
		products_t.add(new Product("루이보스", 4000));
		products_t.add(new Product("자스민", 4000));
		products_t.add(new Product("페퍼민트", 4000));
		products_t.add(new Product("자몽허니블랙티", 4500));
		products_t.add(new Product("그린티", 4000));
		products_t.add(new Product("미숫가루", 4500));
	}
	// ===============================================================
//		products.add(new Product("", ));

}
