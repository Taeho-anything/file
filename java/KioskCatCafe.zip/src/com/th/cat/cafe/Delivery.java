package com.th.cat.cafe;

import java.util.Scanner;

import com.th.cat.utill.Cw;

public class Delivery {
	
	public static void del_run() {

		Scanner sc = new Scanner(System.in);
		String cmd;
		
		Cw.wn("[선택] 3.배달");
		Cw.wn(" ");
		Cw.wn("[1.일반 / 2.퀵 / x.이전메뉴]");

		loop_d: while (true) {
			
//			Kiosk.d1.info();
//			Kiosk.d2.info();
			
			cmd = sc.next();
			switch (cmd) {

			case "1":
				Cw.wn("[선택] 1.일반");
				break;
			case "2":
				Cw.wn("[선택] 2.퀵");
				break;
			case "x":
				Cw.wn("[이전메뉴]");
				break loop_d;
			}
		}
	}
	

}
