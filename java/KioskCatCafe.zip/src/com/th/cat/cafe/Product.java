package com.th.cat.cafe;

import com.th.cat.utill.Cw;

public class Product {
	String name;
	int price;

	Product() {
	};

	Product(String x, int y) {
		name = x;
		price = y;
	}

	void info() {
		Cw.wn("[메뉴]" + this.name + "[가격]" + this.price);
	}

}
