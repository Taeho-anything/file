package com.th.cat.cafe;

public class Stay {

}
