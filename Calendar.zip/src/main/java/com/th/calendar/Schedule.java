package com.th.calendar;

public class Schedule {
	
	public String b_no;
	public String b_text;
	public String b_ch;
	public String b_title;
	public String b_writeTime;
	public String b_date;
	
	
	public Schedule(String b_no, String b_title,String b_date, String b_text, String b_ch) {
		switch(b_ch){
		case "아무거나":
			b_ch="🫥";
			break;
		case "약속":
			b_ch="🤙";
			break;
		case "일":
			b_ch="💼";
			break;
		case "놀기":
			b_ch="🎈";
			break;
		case "운동":
			b_ch="🏋️";
			break;
		}
		this.b_no = b_no;
		this.b_title = b_title;
		this.b_date = b_date;
		this.b_text = b_text;
		this.b_ch = b_ch;
	}
	
	public Schedule(String b_no, String b_title, String b_date, String b_ch) {
		switch(b_ch){
		case "아무거나":
			b_ch="🫥";
			break;
		case "약속":
			b_ch="🤙";
			break;
		case "일":
			b_ch="💼";
			break;
		case "놀기":
			b_ch="🎈";
			break;
		case "운동":
			b_ch="🏋️";
			break;
		}
		
		this.b_no = b_no;
		this.b_title = b_title;
		this.b_date = b_date;
		this.b_ch = b_ch;
	}
	

}
